import { useMemo, useState } from "react";
import { SearchX } from "lucide-react";
import { useSearchParams } from "react-router-dom";
import FilterBar from "../components/FilterBar";
import PropertyCard from "../components/PropertyCard";
import { properties } from "../data/properties";

function Properties() {
  const [searchParams] = useSearchParams();

  const [filters, setFilters] = useState({
    location: searchParams.get("location") || "",
    type: searchParams.get("type") || "",
    price: "",
    bedrooms: "",
    amenity: "",
  });

  const [appliedFilters, setAppliedFilters] = useState(filters);

  const filteredProperties = useMemo(() => {
    return properties.filter((property) => {
      const matchesLocation =
        !appliedFilters.location ||
        property.location
          .toLowerCase()
          .includes(appliedFilters.location.toLowerCase()) ||
        property.city
          .toLowerCase()
          .includes(appliedFilters.location.toLowerCase());

      const matchesType =
        !appliedFilters.type || property.type === appliedFilters.type;

      const matchesPrice =
        !appliedFilters.price ||
        property.price <= Number(appliedFilters.price);

      const matchesBedrooms =
        !appliedFilters.bedrooms ||
        property.bedrooms >= Number(appliedFilters.bedrooms);

      const matchesAmenity =
        !appliedFilters.amenity ||
        property.amenities.includes(appliedFilters.amenity);

      return (
        matchesLocation &&
        matchesType &&
        matchesPrice &&
        matchesBedrooms &&
        matchesAmenity
      );
    });
  }, [appliedFilters]);

  const handleApply = () => {
    setAppliedFilters(filters);
  };

  const handleReset = () => {
    const emptyFilters = {
      location: "",
      type: "",
      price: "",
      bedrooms: "",
      amenity: "",
    };

    setFilters(emptyFilters);
    setAppliedFilters(emptyFilters);
  };

  return (
    <main className="bg-[#f8faf8]">
      <section className="bg-[#173f2a] py-14 text-white">
        <div className="container-width">
          <p className="text-sm font-semibold uppercase tracking-[0.18em] text-green-200">
            Property listings
          </p>

          <h1 className="mt-3 text-4xl font-bold sm:text-5xl">
            Find your perfect rental
          </h1>

          <p className="mt-4 max-w-2xl leading-7 text-green-50/70">
            Browse verified homes and apartments across popular locations.
            Use filters to narrow down your search.
          </p>
        </div>
      </section>

      <section className="container-width -mt-6 pb-20">
        <FilterBar
          filters={filters}
          setFilters={setFilters}
          onApply={handleApply}
          onReset={handleReset}
        />

        <div className="mt-10 flex items-end justify-between gap-4">
          <div>
            <p className="text-sm font-semibold text-gray-400">
              Available properties
            </p>

            <h2 className="mt-1 text-2xl font-bold text-[#173f2a]">
              {filteredProperties.length} homes found
            </h2>
          </div>
        </div>

        {filteredProperties.length > 0 ? (
          <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {filteredProperties.map((property) => (
              <PropertyCard key={property.id} property={property} />
            ))}
          </div>
        ) : (
          <div className="mt-8 rounded-3xl border border-gray-100 bg-white px-6 py-16 text-center">
            <SearchX className="mx-auto text-gray-300" size={50} />

            <h3 className="mt-5 text-xl font-bold text-gray-900">
              No properties found
            </h3>

            <p className="mt-2 text-gray-500">
              Try changing your filters and search again.
            </p>

            <button
              onClick={handleReset}
              className="mt-6 rounded-xl bg-[#173f2a] px-5 py-3 font-semibold text-white"
            >
              Reset Filters
            </button>
          </div>
        )}
      </section>
    </main>
  );
}

export default Properties;